package com.example.hello_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
